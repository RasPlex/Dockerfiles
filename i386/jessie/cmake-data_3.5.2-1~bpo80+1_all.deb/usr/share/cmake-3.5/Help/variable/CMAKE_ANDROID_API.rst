CMAKE_ANDROID_API
-----------------

Default value for the :prop_tgt:`ANDROID_API` target property.
See that target property for additional information.
