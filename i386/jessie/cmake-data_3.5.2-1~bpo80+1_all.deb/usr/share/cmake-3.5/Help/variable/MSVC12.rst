MSVC12
------

``True`` when using Microsoft Visual C++ 12.0.

Set to ``true`` when the compiler is version 12.0 of Microsoft Visual C++.
