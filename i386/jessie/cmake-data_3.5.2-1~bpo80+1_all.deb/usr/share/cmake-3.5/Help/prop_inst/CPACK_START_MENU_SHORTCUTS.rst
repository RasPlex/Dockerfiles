CPACK_START_MENU_SHORTCUTS
--------------------------

Species a list of shortcut names that should be created in the Start Menu
for this file.

The property is currently only supported by the WIX generator.
