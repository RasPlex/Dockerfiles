LINK_FLAGS_<CONFIG>
-------------------

Per-configuration linker flags for a target.

This is the configuration-specific version of LINK_FLAGS.
