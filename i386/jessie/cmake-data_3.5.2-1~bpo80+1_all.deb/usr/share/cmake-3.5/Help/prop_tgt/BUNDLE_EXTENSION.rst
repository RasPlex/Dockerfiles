BUNDLE_EXTENSION
----------------

The file extension used to name a :prop_tgt:`BUNDLE` target on the OS X and iOS.

The default value is ``bundle`` - you can also use ``plugin`` or whatever
file extension is required by the host app for your bundle.
