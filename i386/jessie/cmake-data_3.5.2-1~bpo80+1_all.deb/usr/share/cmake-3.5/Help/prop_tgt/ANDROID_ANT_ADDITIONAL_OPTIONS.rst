ANDROID_ANT_ADDITIONAL_OPTIONS
------------------------------

Set the additional options for Android Ant build system. This is
a string value containing all command line options for the Ant build.
This property is initialized by the value of the
:variable:`CMAKE_ANDROID_ANT_ADDITIONAL_OPTIONS` variable if it is
set when a target is created.
